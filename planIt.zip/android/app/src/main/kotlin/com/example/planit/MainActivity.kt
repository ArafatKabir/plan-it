package com.example.planit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
